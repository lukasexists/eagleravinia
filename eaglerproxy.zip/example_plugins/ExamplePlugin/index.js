const logger = new PLUGIN_MANAGER.Logger("ExamplePlugin");
logger.info("Hi!");
